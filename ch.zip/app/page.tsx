"use client"

import AceChecker from "../ace-checker"

export default function Page() {
  return <AceChecker />
}
